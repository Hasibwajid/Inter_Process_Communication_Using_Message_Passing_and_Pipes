#include <iostream>
#include <sys/socket.h>
#include <netinet/in.h>
#include <unistd.h>
#include <cstring>

using namespace std; 
int main() {
    int serverSocket = socket(AF_INET, SOCK_STREAM, 0);
    if (serverSocket == -1) {
        cerr << "Socket creation failed" << endl;
        return 1;
    }
    sockaddr_in serverAddress;
    serverAddress.sin_family = AF_INET;
    serverAddress.sin_addr.s_addr = INADDR_ANY;
    serverAddress.sin_port = htons(8080); // Port number
    if (bind(serverSocket, reinterpret_cast<sockaddr*>(&serverAddress), sizeof(serverAddress)) == -1) {
        cerr << "Binding failed" << endl;
        return 1;
    }
    if (listen(serverSocket, 5) == -1) {
        cerr << "Listening failed" << endl;
        return 1;
    }

    cout << "Server is listening..." << endl;

    int clientSocket = accept(serverSocket, nullptr, nullptr);
    if (clientSocket == -1) {
        cerr << "Acceptance failed" << endl;
        return 1;
    }

    char message[] = "Hello, client!";
    send(clientSocket, message, strlen(message), 0);

    close(clientSocket);
    close(serverSocket);

    return 0;
}

