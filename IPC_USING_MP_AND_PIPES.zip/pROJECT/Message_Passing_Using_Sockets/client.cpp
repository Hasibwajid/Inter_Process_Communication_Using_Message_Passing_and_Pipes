#include <iostream>
#include <sys/socket.h>
#include <netinet/in.h>
#include <arpa/inet.h> // header for inet_pton
#include <unistd.h>
#include <cstring>

using namespace std; SC

int main() {
    int clientSocket = socket(AF_INET, SOCK_STREAM, 0);
    if (clientSocket == -1) {
        cerr << "Socket creation failed" << endl; 
        return 1;
    }
    sockaddr_in serverAddress;
    serverAddress.sin_family = AF_INET;
    serverAddress.sin_port = htons(8080); // Port number

    if (inet_pton(AF_INET, "127.0.0.1", &serverAddress.sin_addr) <= 0) {
        cerr << "Invalid address" << endl; 
        return 1;
    }
    if (connect(clientSocket, reinterpret_cast<sockaddr*>(&serverAddress), sizeof(serverAddress)) == -1) {
        cerr << "Connection failed" << endl; 
        return 1;
    }

    char buffer[1024] = {0};
    recv(clientSocket, buffer, 1024, 0);
    cout << "Received: " << buffer << endl; 

    close(clientSocket);

    return 0;
}

