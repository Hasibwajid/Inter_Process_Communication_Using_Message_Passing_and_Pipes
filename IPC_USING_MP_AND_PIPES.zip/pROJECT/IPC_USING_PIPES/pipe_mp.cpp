#include <iostream>
#include <unistd.h>

int main() {
    int pipefd[2]; 
    // File descriptors for the pipe:
    // pipefd[0] for reading, 
    //pipefd[1] for writing
    char message[] = "Hello, IPC!"; // Message to be sent through the pipe
    char buffer[100]; // Buffer to receive the message

    if (pipe(pipefd) == -1) {
        std::cerr << "Pipe failed";
        return 1;
    }

    pid_t pid = fork(); // Create a child process

    if (pid < 0) {
        std::cerr << "Fork failed";
        return 1;
    }

    if (pid > 0) { // Parent process
        close(pipefd[0]); // Close the reading end of the pipe

        // Write the message to the pipe
        write(pipefd[1], message, sizeof(message));
        close(pipefd[1]); // Close the writing end of the pipe
    } else { // Child process
        close(pipefd[1]); // Close the writing end of the pipe

        // Read the message from the pipe
        read(pipefd[0], buffer, sizeof(buffer));
        std::cout << "Message received in child process: " << buffer << std::endl;
        close(pipefd[0]); // Close the reading end of the pipe
    }

    return 0;
}

